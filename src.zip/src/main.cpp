#include <iostream>
#include "repl.hpp"

int main()
{
    std::cout << "D-bash — shell réparti (étape 1 : REPL local)\n";
    std::cout << "Tape 'exit' ou Ctrl+D pour quitter.\n\n";
    repl_run();
    return 0; // jamais atteint
}

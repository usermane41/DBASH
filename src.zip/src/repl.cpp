#include <iostream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <readline/readline.h>
#include <readline/history.h>

#include "repl.hpp"
#include "parser.hpp"

static constexpr const char* PROMPT = "dbash> ";

/* ---------- built-ins (stubs pour l'instant) ---------- */

[[noreturn]] static void builtin_exit()
{
    std::cout << "Bye.\n";
    exit(0);
}

static void builtin_ps()
{
    // TODO étape 3 : afficher les processus lancés par d-bash
    std::cout << "[ps] not implemented yet\n";
}

static void builtin_wait_all()
{
    // TODO étape 3 : attendre tous les jobs arrière-plan
    std::cout << "[wait] not implemented yet\n";
}

static void builtin_kill(const Command& cmd)
{
    // TODO étape 3 : kill -sig global_pid
    (void)cmd;
    std::cout << "[kill] not implemented yet\n";
}

/* ---------- dispatch ---------- */

static bool handle_builtin(const Command& cmd)
{
    const auto& name = cmd.name();
    if (name == "exit") { builtin_exit(); }
    if (name == "ps")   { builtin_ps();        return true; }
    if (name == "wait") { builtin_wait_all();  return true; }
    if (name == "kill") { builtin_kill(cmd);   return true; }
    return false;
}

static void execute_command(const Command& cmd)
{
    if (handle_builtin(cmd)) return;

    /*
     * TODO étape 2 : interroger le load-balancer pour choisir la machine cible,
     *               puis fork/exec local ou envoi réseau.
     */
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return;
    }
    if (pid == 0) {
        // Enfant — on construit argv[] juste avant execvp
        auto argv = cmd.argv();
        execvp(argv[0], argv.data());
        perror(argv[0]);
        _exit(127);
    }
    // Parent
    if (!cmd.background) {
        int status;
        waitpid(pid, &status, 0);
    } else {
        std::cout << "[" << pid << "] lancé en arrière-plan\n";
    }
}

/* ---------- boucle principale ---------- */

void repl_run()
{
    char* raw;
    while ((raw = readline(PROMPT)) != nullptr) {
        std::string line(raw);
        if (!line.empty()) add_history(raw);
        free(raw);

        Command cmd = parse_line(line);
        if (cmd.empty()) continue;

        execute_command(cmd);
    }

    // EOF (Ctrl+D)
    std::cout << "\n";
    builtin_exit();
}
